/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.restaurante.entities;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author phmachado
 */
public class Cardapio implements Serializable {

    Map<String, Lanche> opcoes;

    public Cardapio() {
        opcoes = new HashMap<>();
        init();
    }

    private void init() {
        // Cria opcoes
        // X-Bacon
        Lanche lancheXBacon = new Lanche();
        lancheXBacon.adicionaIngrediente(Ingrediente.BACON);
        lancheXBacon.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);
        lancheXBacon.adicionaIngrediente(Ingrediente.QUEIJO);
        opcoes.put("X-Bacon", lancheXBacon);

        // X-Burger
        Lanche lancheXBurger = new Lanche();
        lancheXBurger.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);
        lancheXBurger.adicionaIngrediente(Ingrediente.QUEIJO);
        opcoes.put("X-Burger", lancheXBurger);

        // X-Egg
        Lanche lancheXEgg = new Lanche();
        lancheXEgg.adicionaIngrediente(Ingrediente.OVO);
        lancheXEgg.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);
        lancheXEgg.adicionaIngrediente(Ingrediente.QUEIJO);
        opcoes.put("X-Egg", lancheXEgg);

        // X-Egg Bacon
        Lanche lancheXEggBacon = new Lanche();
        lancheXEggBacon.adicionaIngrediente(Ingrediente.OVO);
        lancheXEggBacon.adicionaIngrediente(Ingrediente.BACON);
        lancheXEggBacon.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);
        lancheXEggBacon.adicionaIngrediente(Ingrediente.QUEIJO);
        opcoes.put("X-Egg Bacon", lancheXEggBacon);
    }

    public Map<String, Lanche> getOpcoes() {
        return opcoes;
    }

    public void setOpcoes(Map<String, Lanche> opcoes) {
        this.opcoes = opcoes;
    }

}
