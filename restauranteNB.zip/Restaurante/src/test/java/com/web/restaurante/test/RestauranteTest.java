/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.restaurante.test;

import com.web.restaurante.entities.Cardapio;
import com.web.restaurante.entities.Ingrediente;
import com.web.restaurante.entities.Lanche;
import java.util.HashMap;
import java.util.Map;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author phmachado
 */
public class RestauranteTest {

    public RestauranteTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {

    }

    @After
    public void tearDown() {

    }

    @Test
    public void testeValoresOpcaoDoCardapio() {

        Cardapio cardapio = new Cardapio();

        // INFLACAO: Os valores dos ingredientes são alterados com frequência e 
        // não gastaríamos que isso influenciasse nos testes automatizados.
        // Aplicado de forma igual em todos os ingredientes. Calculado segundo o
        // valor de 1 ingrediente na criação do teste (ALFACE - Valor = R$ 0,40);
        double fator_inflação = (Ingrediente.ALFACE.getValor() / 0.40);

        for (Map.Entry<String, Lanche> entry : cardapio.getOpcoes().entrySet()) {
            if (entry.getKey().toUpperCase().equals("X-BACON")) {
                assertEquals(6.50 * fator_inflação, entry.getValue().getValor(), 0);
            }

            if (entry.getKey().toUpperCase().equals("X-BURGER")) {
                assertEquals(4.50 * fator_inflação, entry.getValue().getValor(), 0);
            }

            if (entry.getKey().toUpperCase().equals("X-EGG")) {
                assertEquals(5.30 * fator_inflação, entry.getValue().getValor(), 0);
            }

            if (entry.getKey().toUpperCase().equals("X-EGG BACON")) {
                assertEquals(7.30 * fator_inflação, entry.getValue().getValor(), 0);
            }
        }

    }

    @Test
    public void testeValoresPersonalizadosNaoPromocao() {

        Cardapio cardapio = new Cardapio();

        // INFLACAO: Os valores dos ingredientes são alterados com frequência e 
        // não gastaríamos que isso influenciasse nos testes automatizados.
        // Aplicado de forma igual em todos os ingredientes. Calculado segundo o
        // valor de 1 ingrediente na criação do teste (ALFACE - Valor = R$ 0,40);
        double fator_inflação = 1;

        // Personalizar X-Bacon - Adicionar Alface
        Lanche xBacon = cardapio.getOpcoes().get("X-Bacon");
        xBacon.adicionaIngrediente(Ingrediente.ALFACE);
        assertEquals(6.90 * fator_inflação, xBacon.getValor(), 0);

    }

    @Test
    public void testeValoresComPromocao() {

        Cardapio cardapio = new Cardapio();

        // INFLACAO: Os valores dos ingredientes são alterados com frequência e 
        // não gastaríamos que isso influenciasse nos testes automatizados.
        // Aplicado de forma igual em todos os ingredientes. Calculado segundo o
        // valor de 1 ingrediente na criação do teste (ALFACE - Valor = R$ 0,40);
        double fator_inflação = 1;

        // Testa Light
        // Valor = Valor Ingredientes - 10%         
        // Personalizar X-Egg - Adicionar Alface        
        Lanche xEggPersonalizado = cardapio.getOpcoes().get("X-Egg");
        xEggPersonalizado.adicionaIngrediente(Ingrediente.ALFACE);
        assertEquals((xEggPersonalizado.getValorSemPromocao() * 0.9) * fator_inflação, xEggPersonalizado.getValor(), 0);

        // Testa Muita Carne
        // Valor lanche com 2 porcoes = Valor lanche com 3 porcoes        
        // Personalizar X-Burger - Adicionar Hamburger de carne (+1)
        Lanche xBurger2Porcoes = cardapio.getOpcoes().get("X-Burger");
        xBurger2Porcoes.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);

        // Personalizar X-Burger - Adicionar Hamburger de carne (+2)
        Lanche xBurger3Porcoes = cardapio.getOpcoes().get("X-Burger");
        xBurger3Porcoes.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);
        xBurger3Porcoes.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);

        assertEquals(xBurger2Porcoes.getValor(), xBurger3Porcoes.getValor(), 0);

        // Testa Muito Queijo
        // valor lanche com 2 porcoes = valor lanche com 3 porcoes               
         // Personalizar X-Bacon - Adicionar Queijo (+1)
        Lanche xBacon2Porcoes = cardapio.getOpcoes().get("X-Burger");
        xBacon2Porcoes.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);
        xBacon2Porcoes.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);

        // Personalizar X-Burger - Adicionar Hamburger de carne (+2)
        Lanche xBacon3Porcoes = cardapio.getOpcoes().get("X-Burger");
        xBacon3Porcoes.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);
        xBacon3Porcoes.adicionaIngrediente(Ingrediente.HANBURGER_DE_CARNE);

        assertEquals(xBacon2Porcoes.getValor(), xBacon3Porcoes.getValor(), 0);
    }

}
