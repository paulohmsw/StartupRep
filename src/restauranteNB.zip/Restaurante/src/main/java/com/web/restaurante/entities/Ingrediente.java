/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.restaurante.entities;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author phmachado
 */
@XmlRootElement
public enum Ingrediente implements Serializable{
        
    ALFACE             ("Alface", 0.40),
    BACON              ("Bacon", 2.00),
    HANBURGER_DE_CARNE ("Hambúrguer de carne", 3.00),
    OVO                ("Ovo", 0.80),
    QUEIJO             ("Queijo", 1.50);

    private String nome;
    private double valor;
    
    Ingrediente(String nome, double valor) {
        this.nome = nome;
        this.valor = valor;
    }
       
    public String getNome() { 
        return nome; 
    }
    
    public double getValor() { 
        return valor; 
    }

}
