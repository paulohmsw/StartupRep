/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.restaurante.ws;

import com.web.restaurante.entities.Cardapio;
import com.web.restaurante.entities.Ingrediente;
import com.web.restaurante.entities.Lanche;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Map;
import javax.enterprise.context.SessionScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author phmachado
 */
@SessionScoped
@Path("cart")
public class Cesta implements Serializable {

    private Lanche meuLanche;
    private Cardapio cardapio;

    public Cesta() {
        meuLanche = new Lanche();
        cardapio = new Cardapio();
    }

    public Lanche getLanche() {
        return meuLanche;
    }

    public void setLanche(Lanche lanche) {
        this.meuLanche = lanche;
    }
    
    @GET
    @Path("list_opcoes/")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Lanche> getOpcoes() {
        return this.cardapio.getOpcoes();
    }

    @GET
    @Path("set_lanche/{lanche}")
    @Consumes(MediaType.TEXT_PLAIN)
    public void clonaLanche(@PathParam("lanche") String nome) {
        Lanche lanche = this.cardapio.getOpcoes().get(nome);
        this.meuLanche.clonaLanche(lanche);
    }

    @GET
    @Path("add_ingrediente/{ingrediente}")
    @Consumes(MediaType.TEXT_PLAIN)
    public void adicionaIngrediente(@PathParam("ingrediente") String nome) {
        Ingrediente ingrediente = Ingrediente.valueOf(nome.toUpperCase());
        this.meuLanche.adicionaIngrediente(ingrediente);
    }

    @GET
    @Path("del_ingrediente/{ingrediente}")
    @Consumes(MediaType.TEXT_PLAIN)
    public void removeIngrediente(@PathParam("ingrediente") String nome) {
        Ingrediente ingrediente = Ingrediente.valueOf(nome.toUpperCase());
        this.meuLanche.removeIngrediente(ingrediente);
    }
    
    @GET
    @Path("clean_ingrediente/")
    public void removeTodosOsIngredientes() {
        this.meuLanche.zeraIngredientes();
    }
    
    @GET
    @Path("list_ingredientes/")
    @Produces(MediaType.APPLICATION_JSON)
    public Map<Ingrediente, Integer> getIngredientes() {
        return this.meuLanche.getIngredientes();
    }

    @GET
    @Path("list_ingredientes/{lanche}")
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    public Map<Ingrediente, Integer> getIngredientes(@PathParam("lanche") String nome) {
        return this.cardapio.getOpcoes().get(nome).getIngredientes();
    }

    @GET
    @Path("list_valor/")
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.TEXT_PLAIN)
    public String getValor() {
        Locale localeBR = new Locale("pt", "BR");
        NumberFormat currencyBR = NumberFormat.getCurrencyInstance(localeBR);
        return currencyBR.format(this.meuLanche.getValor());
    }

    @GET
    @Path("list_valor/{lanche}")
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    public double getValor(@PathParam("lanche") String nome) {
        return this.cardapio.getOpcoes().get(nome).getValor();
    }

}
