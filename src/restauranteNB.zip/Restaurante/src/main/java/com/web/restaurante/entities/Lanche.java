/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.web.restaurante.entities;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author phmachado
 */
@XmlRootElement
public class Lanche implements Serializable {

    Map<Ingrediente, Integer> ingredientes;

    public Lanche() {
        ingredientes = new HashMap<>();
        for (Ingrediente ingrediente : Ingrediente.values()) {
            ingredientes.put(ingrediente, 0);
        }
    }

    public Map<Ingrediente, Integer> getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(Map<Ingrediente, Integer> ingredientes) {
        this.ingredientes = ingredientes;
    }

    public void adicionaIngrediente(Ingrediente ingrediente) {
        getIngredientes().put(ingrediente, getIngredientes().get(ingrediente) + 1);
    }

    public void removeIngrediente(Ingrediente ingrediente) {
        if (getIngredientes().get(ingrediente) > 0) {
            getIngredientes().put(ingrediente, getIngredientes().get(ingrediente) - 1);
        }
    }

    public void clonaLanche(Lanche lanche) {
        for (Map.Entry<Ingrediente, Integer> entry : lanche.ingredientes.entrySet()) {
            getIngredientes().put(entry.getKey(), entry.getValue());
        }
    }

    public void zeraIngredientes() {
        for (Map.Entry<Ingrediente, Integer> entry : ingredientes.entrySet()) {
            getIngredientes().put(entry.getKey(), 0);
        }
    }

    public double getValorSemPromocao() {
        double valor = 0.0;

        //Soma valor dos ingredientes
        for (Map.Entry<Ingrediente, Integer> entry : ingredientes.entrySet()) {
            int quantidade = entry.getValue();
            double preco = entry.getKey().getValor();

            valor += (quantidade * preco);
        }

        return valor;
    }

    public double getValor() {
        double valor = 0.0;

        //Soma valor dos ingredientes
        for (Map.Entry<Ingrediente, Integer> entry : ingredientes.entrySet()) {
            int quantidade = entry.getValue();
            double preco = entry.getKey().getValor();

            // Muita Carne: A cada 3 porções de carne o cliente só paga 2. Se o lanche tiver 6 porções, 
            // o cliente pagará 4. Assim por diante...
            // Muito Queijo: A cada 3 porções de queijo o cliente só paga 2. Se o lanche tiver 6 porções, 
            // o cliente pagará 4. Assim por diante...
            if ((entry.getKey() == Ingrediente.HANBURGER_DE_CARNE) || (entry.getKey() == Ingrediente.QUEIJO)) {
                quantidade = (((quantidade / 3) * 2) + (quantidade % 3));
            }

            valor += (quantidade * preco);
        }

        // Aplica promocao se elegivel
        // Light: Se o lanche tem alface e não tem bacon, ganha 10% de desconto.
        if ((ingredientes.get(Ingrediente.ALFACE) > 0) && (ingredientes.get(Ingrediente.BACON) == 0)) {
            valor = valor * 0.9;
        }

        return (valor * 100L) / 100.00;
    }

}
